package com.gopi.main;

import java.sql.Connection;
import java.sql.SQLException;

import com.gopi.util.DBUtil;

public class MainModule {
	
	public static void main(String[] args) {
	   Connection connection;

		try {
			connection=DBUtil.getConnection();
		}catch(ClassNotFoundException c) {
			System.out.println("JDBC not connected");
		}
		catch(SQLException s) {
			System.out.println("Sql Exception");
		}
	}

}
