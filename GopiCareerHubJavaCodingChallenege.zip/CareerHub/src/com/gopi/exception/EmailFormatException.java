package com.gopi.exception;

public class EmailFormatException extends Exception{
	private static final long serialVersionUID = 1L;

	public EmailFormatException(String message) {
		super(message);
	}

}
