package com.gopi.exception;

public class ApplicationDeadlineException extends Exception {
	private static final long serialVersionUID = 1L;

	public ApplicationDeadlineException(String message) {
		super(message);
		
	}

}
