package com.gopi.exception;

public class SalaryCalculationException extends Exception{
	private static final long serialVersionUID = 1L;

	public SalaryCalculationException(String message) {
		super(message);
	}

}
