package com.gopi.dao;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.gopi.entity.Applicant;
import com.gopi.entity.Company;
import com.gopi.entity.JobApplication;
import com.gopi.entity.JobListing;
import com.gopi.exception.ApplicationDeadlineException;
import com.gopi.exception.DatabaseConnectionException;
import com.gopi.exception.FileUploadException;
import com.gopi.exception.SalaryCalculationException;
import com.gopi.util.DBUtil;

public class DatabaseManager {
    private static Connection connection;

    public DatabaseManager(){
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DBUtil.getConnection();
           
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public void initializeDatabase() throws DatabaseConnectionException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS Jobs (" +
                    "JobID INT PRIMARY KEY," +
                    "CompanyID INT," +
                    "JobTitle VARCHAR(255)," +
                    "JobDescription TEXT," +
                    "JobLocation VARCHAR(255)," +
                    "Salary DECIMAL(10, 2)," +
                    "JobType VARCHAR(50)," +
                    "PostedDate TIMESTAMP" +
                    ")");

           
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS Companies (" +
                    "CompanyID INT PRIMARY KEY," +
                    "CompanyName VARCHAR(255)," +
                    "Location VARCHAR(255)" +
                    ")");

            
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS Applicants (" +
                    "ApplicantID INT PRIMARY KEY," +
                    "FirstName VARCHAR(50)," +
                    "LastName VARCHAR(50)," +
                    "Email VARCHAR(255)," +
                    "Phone VARCHAR(20)," +
                    "Resume TEXT" +
                    ")");

           
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS Applications (" +
                    "ApplicationID INT PRIMARY KEY," +
                    "JobID INT," +
                    "ApplicantID INT," +
                    "ApplicationDate TIMESTAMP," +
                    "CoverLetter TEXT," +
                    "FOREIGN KEY (JobID) REFERENCES Jobs(JobID)," +
                    "FOREIGN KEY (ApplicantID) REFERENCES Applicants(ApplicantID)" +
                    ")");
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    public void insertJobListing(JobListing job) throws DatabaseConnectionException {
        try (PreparedStatement preparedStatement = connection.prepareStatement(
                "INSERT INTO Jobs (JobID, CompanyID, JobTitle, JobDescription, JobLocation, Salary, JobType, PostedDate) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)")) {

            preparedStatement.setInt(1, job.getJobID());
            preparedStatement.setInt(2, job.getCompanyID());
            preparedStatement.setString(3, job.getJobTitle());
            preparedStatement.setString(4, job.getJobDescription());
            preparedStatement.setString(5, job.getJobLocation());
            preparedStatement.setDouble(6, job.getSalary());
            preparedStatement.setString(7, job.getJobType());
            preparedStatement.setTimestamp(8, new Timestamp(job.getPostedDate().getTime()));

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
        	throw new DatabaseConnectionException(e.getMessage());
        }
    }

    public void insertCompany(Company company) throws DatabaseConnectionException{
        try (PreparedStatement preparedStatement = connection.prepareStatement(
                "INSERT INTO Companies (CompanyID, CompanyName, Location) VALUES (?, ?, ?)")) {

            preparedStatement.setInt(1, company.getCompanyID());
            preparedStatement.setString(2, company.getCompanyName());
            preparedStatement.setString(3, company.getLocation());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
        	throw new DatabaseConnectionException(e.getMessage());
        }
    }
    
   

    public void insertApplicant(Applicant applicant) throws DatabaseConnectionException,FileUploadException{
        handleFileUpload(applicant.getResume());
        try (PreparedStatement preparedStatement = connection.prepareStatement(
                "INSERT INTO Applicants (ApplicantID, FirstName, LastName, Email, Phone, Resume) VALUES (?, ?, ?, ?, ?, ?)")) {

            preparedStatement.setInt(1, applicant.getApplicantID());
            preparedStatement.setString(2, applicant.getFirstName());
            preparedStatement.setString(3, applicant.getLastName());
            preparedStatement.setString(4, applicant.getEmail());
            preparedStatement.setString(5, applicant.getPhone());
            preparedStatement.setString(6, applicant.getResume());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
        	throw new DatabaseConnectionException(e.getMessage());
        }
    }
    
    public void checkApplicationDeadline(Date applicationDate, Date deadline) throws ApplicationDeadlineException {
        if (applicationDate.after(deadline)) {
            throw new ApplicationDeadlineException("Application deadline has passed. Submission not allowed.");
        }
    }

    public void insertJobApplication(JobApplication application) throws DatabaseConnectionException,ApplicationDeadlineException{
    	checkApplicationDeadline(application.getApplicationDate(),new Date());
        try (PreparedStatement preparedStatement = connection.prepareStatement(
                "INSERT INTO Applications (ApplicationID, JobID, ApplicantID, ApplicationDate, CoverLetter) VALUES (?, ?, ?, ?, ?)")) {

            preparedStatement.setInt(1, application.getApplicationID());
            preparedStatement.setInt(2, application.getJobID());
            preparedStatement.setInt(3, application.getApplicantID());
            preparedStatement.setTimestamp(4, new Timestamp(application.getApplicationDate().getTime()));
            preparedStatement.setString(5, application.getCoverLetter());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
        	throw new DatabaseConnectionException(e.getMessage());
        }
    }

    public List<JobListing> getJobListings() throws DatabaseConnectionException {
        List<JobListing> jobListings = new ArrayList<>();

        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Jobs");

            while (resultSet.next()) {
                JobListing job = new JobListing(
                        resultSet.getInt("JobID"),
                        resultSet.getInt("CompanyID"),
                        resultSet.getString("JobTitle"),
                        resultSet.getString("JobDescription"),
                        resultSet.getString("JobLocation"),
                        resultSet.getDouble("Salary"),
                        resultSet.getString("JobType"),
                        resultSet.getTimestamp("PostedDate")
                );
                jobListings.add(job);
            }
        } catch (SQLException e) {
        	throw new DatabaseConnectionException(e.getMessage());
        }

        return jobListings;
    }

    public List<Company> getCompanies() throws DatabaseConnectionException{
        List<Company> companies = new ArrayList<>();

        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Companies");

            while (resultSet.next()) {
                Company company = new Company(
                        resultSet.getInt("CompanyID"),
                        resultSet.getString("CompanyName"),
                        resultSet.getString("Location")
                );
                companies.add(company);
            }
        } catch (SQLException e) {
        	throw new DatabaseConnectionException(e.getMessage());
        }

        return companies;
    }

    public List<Applicant> getApplicants() throws DatabaseConnectionException{
        List<Applicant> applicants = new ArrayList<>();

        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Applicants");

            while (resultSet.next()) {
                Applicant applicant = new Applicant(
                        resultSet.getInt("ApplicantID"),
                        resultSet.getString("FirstName"),
                        resultSet.getString("LastName"),
                        resultSet.getString("Email"),
                        resultSet.getString("Phone"),
                        resultSet.getString("Resume")
                );
                applicants.add(applicant);
            }
        } catch (SQLException e) {
        	throw new DatabaseConnectionException(e.getMessage());
        }

        return applicants;
    }

    public List<JobApplication> getApplicationsForJob(int jobID) throws DatabaseConnectionException{
        List<JobApplication> applications = new ArrayList<>();

        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Applications WHERE JobID = ?")) {
            preparedStatement.setInt(1, jobID);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                JobApplication application = new JobApplication(
                        resultSet.getInt("ApplicationID"),
                        resultSet.getInt("JobID"),
                        resultSet.getInt("ApplicantID"),
                        resultSet.getTimestamp("ApplicationDate"),
                        resultSet.getString("CoverLetter")
                );
                applications.add(application);
            }
        } catch (SQLException e) {
        	throw new DatabaseConnectionException(e.getMessage());
        }

        return applications;
    }
    public double calculateAverageSalary() throws DatabaseConnectionException, SalaryCalculationException {
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery("SELECT Salary FROM Jobs");

            List<Double> salaries = new ArrayList<>();

            while (resultSet.next()) {
                double salary = resultSet.getDouble("Salary");

                if (salary < 0) {
                    throw new SalaryCalculationException("Negative salary found in job listings. JobID: " + resultSet.getInt("JobID"));
                }

                salaries.add(salary);
            }

            if (salaries.isEmpty()) {
                throw new SalaryCalculationException("No job listings found to calculate average salary");
            }

          
            double sum = 0;
            for (double salary : salaries) {
                sum += salary;
            }

            return sum / salaries.size();

        } catch (SQLException e) {
            throw new DatabaseConnectionException("Error calculating average salary: " + e.getMessage());
        }
    }
    public void handleFileUpload(String filePath) throws FileUploadException {
        try {
       
            Path path = Paths.get(filePath);

            if (!Files.exists(path)) {
                throw new NoSuchFileException(filePath);
            }

            long fileSize = Files.size(path);
            long maxFileSize = 1024 * 1024; 

            if (fileSize > maxFileSize) {
                throw new FileUploadException("File size exceeded the maximum allowed size");
            }

            String fileFormat = getFileFormat(path);

            if (!isValidFileFormat(fileFormat)) {
                throw new FileUploadException("Unsupported file format: " + fileFormat);
            }

           

        } catch (NoSuchFileException e) {
            throw new FileUploadException("File not found: " + e.getFile());
        } catch (IOException e) {
            throw new FileUploadException("Error uploading file: " + e.getMessage());
        } catch (Exception e) {
            throw new FileUploadException("Unexpected error during file upload: " + e.getMessage());
        }
    }
    private String getFileFormat(Path filePath) {
        String fileName = filePath.getFileName().toString();
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex > 0 && dotIndex < fileName.length() - 1) {
            return fileName.substring(dotIndex + 1).toLowerCase();
        }
        return null;
    }
    private boolean isValidFileFormat(String fileFormat) {
        return "pdf".equalsIgnoreCase(fileFormat) || "docx".equalsIgnoreCase(fileFormat);
    }
    
    public static void searchJobListingsBySalary(double minSalary, double maxSalary)throws DatabaseConnectionException {
            String sql = "SELECT JobTitle, CompanyName, Salary FROM Jobs WHERE Salary BETWEEN ? AND ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setDouble(1, minSalary);
                preparedStatement.setDouble(2, maxSalary);

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String jobTitle = resultSet.getString("JobTitle");
                        String companyName = resultSet.getString("CompanyName");
                        double salary = resultSet.getDouble("Salary");

                        System.out.println("Job Title: " + jobTitle + ", Company: " + companyName + ", Salary: " + salary);
                    }
                }catch(SQLException e) {
                	e.printStackTrace();
                }
            }catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
