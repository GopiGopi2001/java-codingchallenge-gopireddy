package com.gopi.entity;

import java.util.Date;
import java.util.List;
import java.util.Random;

import com.gopi.dao.DatabaseManager;
import com.gopi.exception.ApplicationDeadlineException;
import com.gopi.exception.DatabaseConnectionException;

public class JobListing {
    private int jobID;
    private int companyID;
    private String jobTitle;
    private String jobDescription;
    private String jobLocation;
    private double salary;
    private String jobType;
    private Date postedDate;

   
    public JobListing(int jobID, int companyID, String jobTitle, String jobDescription, String jobLocation,
                      double salary, String jobType, Date postedDate) {
        this.jobID = jobID;
        this.companyID = companyID;
        this.jobTitle = jobTitle;
        this.jobDescription = jobDescription;
        this.jobLocation = jobLocation;
        this.salary = salary;
        this.jobType = jobType;
        this.postedDate = postedDate;
    }
    
    public int getJobID() {
        return jobID;
    }

    public void setJobID(int jobID) {
        this.jobID = jobID;
    }

    public int getCompanyID() {
        return companyID;
    }

    public void setCompanyID(int companyID) {
        this.companyID = companyID;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public String getJobLocation() {
        return jobLocation;
    }

    public void setJobLocation(String jobLocation) {
        this.jobLocation = jobLocation;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public Date getPostedDate() {
        return postedDate;
    }

    public void setPostedDate(Date postedDate) {
        this.postedDate = postedDate;
    }
    public int generateUniqueApplicationID() {
        long timestamp = System.currentTimeMillis();
        int random = new Random().nextInt(10000);

        return (int) (timestamp + random);
    }
   
    public void apply(int applicantID, String coverLetter) throws DatabaseConnectionException,ApplicationDeadlineException{
        JobApplication jobApplication = new JobApplication(
                generateUniqueApplicationID(), 
                this.jobID,
                applicantID,
                new Date(), 
                coverLetter
        );

        DatabaseManager databaseManager = new DatabaseManager();
        databaseManager.insertJobApplication(jobApplication);
    }

    public List<Applicant> getApplicants() throws DatabaseConnectionException{
        DatabaseManager databaseManager = new DatabaseManager();
        return databaseManager.getApplicants();
    }

}
