package com.gopi.entity;

import java.util.Date;

import java.util.Random;
import java.util.regex.Pattern;

import com.gopi.dao.DatabaseManager;
import com.gopi.exception.*;

public class Applicant {
    private int applicantID;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String resume;

    
    public Applicant(int applicantID, String firstName, String lastName, String email, String phone, String resume) {
        this.applicantID = applicantID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.resume = resume;
    }

    public int getApplicantID() {
        return applicantID;
    }

    public void setApplicantID(int applicantID) {
        this.applicantID = applicantID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }
    
    private int generateUniqueApplicationID() {
        long timestamp = System.currentTimeMillis();
        int random = new Random().nextInt(10000); 

        return (int) (timestamp + random);
    }

    private void validateEmailFormat(String email) throws EmailFormatException {
        String emailRegex = "^[a-zA-Z0-9_+&-]+(?:\\.[a-zA-Z0-9_+&-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);

        if (!pattern.matcher(email).matches()) {
            throw new EmailFormatException("Invalid email format");
        }
    }
    
    public void createProfile(int applicantID,String email, String firstName, String lastName, String phone,String resume) throws DatabaseConnectionException,EmailFormatException,FileUploadException {
       
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.resume=resume;
        this.applicantID=applicantID;
        validateEmailFormat(this.email);

        DatabaseManager databaseManager = new DatabaseManager();
        databaseManager.insertApplicant(this);
    }

    public void applyForJob(int jobID, String coverLetter) throws DatabaseConnectionException,ApplicationDeadlineException{
        JobApplication jobApplication = new JobApplication(
                generateUniqueApplicationID(), 
                jobID,
                this.applicantID,
                new Date(), 
                coverLetter
        );

        DatabaseManager databaseManager = new DatabaseManager();
        databaseManager.insertJobApplication(jobApplication);
    }

   
  
}
