package com.gopi.entity;
import com.gopi.dao.*;
import com.gopi.exception.DatabaseConnectionException;

import java.util.List;
import java.util.Random;
import java.util.Date;

public class Company {
    private int companyID;
    private String companyName;
    private String location;

    public Company(int companyID,String companyName,String location) {
    	this.companyID=companyID;
    	this.companyName=companyName;
    	this.location=location;
    }
    public int getCompanyID() {
        return companyID;
    }

    public void setCompanyID(int companyID) {
        this.companyID = companyID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    
    public int generateUniqueJobID() {
        long timestamp = System.currentTimeMillis();
        int random = new Random().nextInt(10000); 

        return (int) (timestamp + random);
    }
   
    public void postJob(String jobTitle, String jobDescription, String jobLocation, double salary, String jobType) throws DatabaseConnectionException{
       
        JobListing newJob = new JobListing(
                generateUniqueJobID(), 
                this.companyID,
                jobTitle,
                jobDescription,
                jobLocation,
                salary,
                jobType,
                new Date() 
        );

        DatabaseManager databaseManager = new DatabaseManager();
        databaseManager.insertJobListing(newJob);
    }

    public List<JobListing> getJobs() throws DatabaseConnectionException{
     
        DatabaseManager databaseManager = new DatabaseManager();
        return databaseManager.getJobListings();
    }

    
}