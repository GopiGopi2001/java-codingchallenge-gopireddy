package com.gopi.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	
	public static Connection connection;
	
	public static Connection getConnection() throws SQLException,ClassNotFoundException {
		 
		String connectionString = "jdbc:mysql://"+"localhost"+":"+"3306"+"/"+"careerhubdata"+"?user="+"root"+"&password="+"Gopi@12345";
		
		connection = DriverManager.getConnection(connectionString);
		System.out.println("Connection Established:");
		return connection;
	}
	
	public static void closeConnection() throws SQLException {
		connection.close();
	}

}
